A flask web app to plausibly colorize grayscale face portraits using deep learning.

Credits : https://github.com/mtobeiyf/keras-flask-deploy-webapp